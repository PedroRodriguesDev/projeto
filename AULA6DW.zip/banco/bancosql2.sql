USE manterpais;
INSERT INTO `manterpais` (`id`,`nome`,`populacao`,`area`) VALUES (22,'Estados Unidos','3279','9834000');
INSERT INTO `manterpais` (`id`,`nome`,`populacao`,`area`) VALUES (12,'Alemanha','82706','357386');
INSERT INTO `manterpais` (`id`,`nome`,`populacao`,`area`) VALUES (2,'França','66994','643801');
