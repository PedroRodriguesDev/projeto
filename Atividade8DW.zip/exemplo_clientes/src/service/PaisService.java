package service;

import java.util.ArrayList;

import model.Cliente;
import dao.PaisDAO;

public class PaisService {
	PaisDAO dao;
	
	public PaisService(){
		dao = new PaisDAO();
	}
	public ArrayList<Cliente> listarClientes(){
		return dao.listarClientes();
	}
	public ArrayList<Cliente> listarClientes(String chave){
		return dao.listarClientes(chave);
	}

}
