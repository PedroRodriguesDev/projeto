select * from `manterpais`;
CREATE SCHEMA IF NOT EXISTS  `manterpais` DEFAULT CHARACTER SET utf8;
-- Table manterpais

CREATE DATABASE `manterpais`;
USE `manterpais` ;
CREATE TABLE IF NOT EXISTS manterpais (
 `nome` VARCHAR(100) NOT NULL,
  `populacao`  bigint,
  `area`  numeric(15,2),
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

