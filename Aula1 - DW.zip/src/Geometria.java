import java.util.ArrayList;
public class Geometria {


	static int base  ;
	static int altura ;
	static int perimetro;
	static int area;
	static int diagonal;
	static int d;
	public static void main (String args[]) {
		ArrayList<Poligono> poligono = new ArrayList<>();
		poligono.add(new Retangulo(5, 6));
		poligono.add(new Losango(2,5));
		poligono.add(new Triangulo(8,2));
		poligono.add(new Quadrado(5,4));
		for(Poligono pol:poligono) {
			System.out.println(pol.getBase());
			System.out.println(pol.getAltura());
		
			
		
		area = base * altura;
		perimetro = 2*base + 2*altura;
	    diagonal = d = (2 * area) ^ 1/2;
		   System.out.println("A area � " + area );
		   System.out.println("O perimetro � " + perimetro);
		   System.out.println("A diagonal � " + diagonal);
		}
		
	}
	

	}		

		
		
		
		
	


