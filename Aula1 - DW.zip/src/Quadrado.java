
public class Quadrado extends Poligono implements Diagonal {

	public Quadrado(int base, int altura) {
		super(base , altura);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculaDiagonal() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}


}
