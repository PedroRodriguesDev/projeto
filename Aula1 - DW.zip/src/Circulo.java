
public class Circulo extends Figura {

	@Override
	public double area () {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}

	 private double altura;
     private double raio;
     private double volume;

public Circulo(double raio, double altura){
    this.raio = raio;
    this.altura = altura;
    this.volume=(raio*raio)*altura;
}

public double getAltura() {
    return altura;
}

public void setAltura(double altura) {
    this.altura = altura;
}

public double getRaio() {
    return raio;
}

public void setRaio(double raio) {
    this.raio = raio;
}

public double getVolume() {
    return volume;
}

public void setVolume(double volume) {
    this.volume = volume;
}



}

