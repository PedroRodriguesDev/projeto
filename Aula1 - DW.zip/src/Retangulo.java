
public class Retangulo extends Poligono implements Diagonal {

	public Retangulo(int base, int altura) {
		super(base, altura);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculaDiagonal() {
	return ((Math.pow(getAltura(), 2) + Math.pow(getBase(), 2)) * 0.5);
		}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}
	}

	

