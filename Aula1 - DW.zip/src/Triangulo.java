
public class Triangulo extends Poligono {

	public Triangulo(int base, int altura) {
		super(base, altura);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double area() {
		return super.area()/2 ;
	}

	@Override
	public double volume() {
		// TODO Auto-generated method stub
		return 0;
	}

}
