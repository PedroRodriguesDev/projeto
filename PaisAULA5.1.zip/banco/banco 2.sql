USE `Pais` ;
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (1,'Estados Unidos','327.266.748','9.834.000');
