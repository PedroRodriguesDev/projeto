USE `vendas` ;
INSERT INTO `pais` (`id`,`nome`,`populacao`,`area`) VALUES (1,'Estados Unidos','327.266.748','9.834.000');
INSERT INTO `pais`  (`id`,`nome`,`populacao`,`area`) VALUES (2,"Alemanha","82.790.996","357.386" );
INSERT INTO `pais`  (`id`,`nome`,`populacao`,`area`) VALUES (3,"França","66,995.668","643.801" );