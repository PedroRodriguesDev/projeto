import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Pais {
	
	private int id;
	String nome;
	long populacao;
	double area;
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	public Pais(int i, Object object, Object object2, Object object3){
		
	}

	public Pais(int id, String nome, long populacao, double area) {
		this.id = id;
		this.nome = nome;
		this.populacao = populacao;
		this.area = area;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public long getPopulacao() {
		return populacao;
	}

	public void setPopulacao(long populacao) {
		this.populacao = populacao;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}
	
		public Connection obtemConexao1() throws SQLException {
			return DriverManager
					.getConnection("jdbc:mysql://localhost:3306/vendas?useTimezone=true&serverTimezone=America/Sao_Paulo&user=Alunos&password=alunos");
		}

		public void setPopulacao(String string) {
			
		}

		public void setArea(String string) {
			
			
		}
	
	
	public void criar() {
		String sqlInsert = "INSERT INTO Pais(nome, id, populacao, area) VALUES (?, ?, ?)";
		try (Connection conn = obtemConexao1();
				PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setString(1, getNome());
			stm.setInt(2, getId());
			stm.setLong(3, getPopulacao());
			stm.setDouble(3, getArea());
			stm.execute();
			String sqlQuery  = "SELECT LAST_INSERT_ID()";
			try(PreparedStatement stm2 = conn.prepareStatement(sqlQuery);
				ResultSet rs = stm2.executeQuery();) {
				if(rs.next()){
					setId(rs.getInt(1));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizar() {
		String sqlUpdate = "UPDATE Pais SET nome=?, id=?, populacao=?, area=? WHERE id=?";
		try (Connection conn = obtemConexao1();
				PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
			stm.setString(1, getNome());
			stm.setInt(2, getId());
			stm.setLong(3, getPopulacao());
			stm.setDouble(3, getArea());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir() {
		String sqlDelete = "DELETE FROM Pais WHERE id = ?";
		try (Connection conn = obtemConexao1();
				PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
			stm.setInt(1, getId());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void carregar() {
		String sqlSelect = "SELECT nome, id, populacao, area FROM Pais WHERE Pais.id = ?";
		try (Connection conn = obtemConexao1();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setInt(1, getId());
			try (ResultSet rs = stm.executeQuery();) {
				if (rs.next()) {
					setNome(rs.getString("nome"));
					setId(rs.getInt("id"));
					setPopulacao(rs.getLong("popula��o"));
					setArea(rs.getDouble("�rea"));
				} else {
					setId(-1);
					setNome(null);
					setPopulacao(10000);
					setArea(15);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
	}


	public long maiorPopulacao() {
		return populacao;
	}
	
	public double menorArea() {
		return area;
	}
	
	@Override
	public String toString() {
		return "Pais [id=" + id + ", nome=" + nome + 
				", populacao=" + populacao + ", area=" + area + "]";
	}

	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pais other = (Pais) obj;
		if (Double.doubleToLongBits(area) != Double.doubleToLongBits(other.area))
			return false;
		if (id != other.id)
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (populacao != other.populacao)
			return false;
		return true;
	}

	
	
	
	
}
